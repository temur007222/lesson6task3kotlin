package com.example.lesson6task3kotlin

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.lesson6task3kotlin.Adapter.MemberAdapter
import com.example.lesson6task3kotlin.Model.Member

class MainActivity : AppCompatActivity() {

    private lateinit var context: Context
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initView()

        val members: List<Member> = prepareMemberList()
        refreshAdapter(members as ArrayList<Member>)
    }

    private fun initView() {
        context = this
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(context, 2)
    }

    private fun refreshAdapter(members: ArrayList<Member>) {
        val adapter = MemberAdapter(context, members)
        recyclerView!!.adapter = adapter
        recyclerView!!.isNestedScrollingEnabled = false
    }

    private fun prepareMemberList(): List<Member> {
        val members: MutableList<Member> = ArrayList<Member>()
        for (i in 1..14) {
            members.add(Member(1 + i, "Temur $i"))
        }
        return members
    }
}
package com.example.lesson6task3kotlin.Model

class Member(i: Int, s: String) {
    var lastName: String = ""

    fun Member(profile: Int, lastName: String) {
        this.lastName = lastName
    }
   override fun toString():String{return lastName}
    fun getLastname(): String {
        return lastName
    }
}